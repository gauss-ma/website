/* ========================================================================================== */
// BUDGET CONTROLLER
var budgetController = (function() {
    
    var Item = function(id, tipo, cantidad) {
        this.id = id;
        this.tipo = tipo;
	this.cantidad=cantidad
	if (tipo=="AERMOD"){ 
	  	this.precio = cantidad*10000;
	}else if(tipo=="CALPUFF"){
        	this.precio = cantidad*20000;
        }else if(tipo=="WRF-CHEM"){
         	this.precio = cantidad*50000;
	};

    }; 
        
    var data = {
        allItems: {
            item: [],
        },
        total: 0,
    };
    
    var calculateTotal = function() {
        var sum = 0;
        data.allItems['item'].forEach(function(cur) {
            sum += cur.precio;
        });
        data.total = sum;
    };

    
    return {
        addItem: function(tipo,cantidad) {
            var newItem, ID;
            
            // Create new ID
            if (data.allItems['item'].length > 0) {
                ID = data.allItems['item'][data.allItems['item'].length - 1].id + 1;
            } else {
                ID = 0;
            }
            newItem = new Item(ID,tipo,cantidad);
            
            // Push it into our data structure
            data.allItems['item'].push(newItem);
            
            // Return the new element
            return newItem;
        },
        
        
        deleteItem: function(id) {
            var ids, index;
            
            ids = data.allItems['item'].map(function(current) {
                return current.id;
            });

            index = ids.indexOf(id);

            if (index !== -1) {
                data.allItems['item'].splice(index, 1);
            }
            
        },
        
        
        calculateBudget: function() {
            calculateTotal();
            data.budget = data.totals;
        },
        
        getBudget: function() {
            return {
                budget: data.total,
            };
        },
        
        testing: function() {
            console.log(data);
        }
    };
    
})();







/* ========================================================================================== */
// UI CONTROLLER
var UIController = (function() {
    
    var DOMstrings = {
        HTMLinput_Tipo: '.add__tipo',
        HTMLinput_Cantidad: '.add__cantidad',

        HTML_addItemBtn: '.addItem--btn',
        HTML_rmvItemBtn: '.rmvItem--btn',
        
	ContainerList: '.cotizacion__list',
        
        budgetLabel: '.budget__value',
        
        dateLabel:'.budget__title--month'
       
    };
         var  formatNumber = function(num){
             var numSplit,int, decimal;
             num = Math.abs(num);
             num = num.toFixed(2);
             numSplit = num.split('.');
             int = numSplit[0];
             if(int.length > 3)
                 {
                   int = int.substr(0,int.length -3) + ',' + int.substr(int.length -3,int.length);
                 }
             decimal = numSplit[1];
	     return  '$ ' + int + '.' + decimal;
         };
        
    
    	 var nodeListForEach = function(list, callback) {
    	    for (var i = 0; i < list.length; i++) {
    	        callback(list[i], i);
    	    }
         };
    
    
    return {
        getInput: function() {
            return {
                tipo: document.querySelector(DOMstrings.HTMLinput_Tipo).value, 			
                cantidad: parseFloat(document.querySelector(DOMstrings.HTMLinput_Cantidad).value)
                //description: document.querySelector(DOMstrings.inputDescription).value,
            };
        },
        addListItem: function(obj) {
            var html, newHtml, element;
            // Create HTML string with placeholder text
            element = DOMstrings.ContainerList;
            html = '<div class="item clearfix" id="inc-%id%"> <div class="item__tipo">%tipo%</div><div class="item__cantidad">x %cantidad%</div><div class="right clearfix"><div class="item__precio">%precio%</div><div class="item__delete"><button class="rmvItem--btn"><i class="ion-ios-close-outline"></i></button></div></div></div>';
            
            // Replace the placeholder text with some actual data
            newHtml = html.replace('%id%', obj.id);
            newHtml = html.replace('%cantidad%', obj.cantidad);
            newHtml = newHtml.replace('%tipo%', obj.tipo);
            newHtml = newHtml.replace('%precio%', formatNumber(obj.precio));
            
            // Insert the HTML into the DOM
            document.querySelector(element).insertAdjacentHTML('beforeend', newHtml);
        },
        deleteListItem : function(selectorID){
           var el = document.getElementById(selectorID);
            el.parentNode.removeChild(el);
            
        },
        clearFields: function() {
            var fields, fieldsArr;
            fields = document.querySelectorAll(DOMstrings.HTMLinput_Tipo + ', ' + DOMstrings.HTMLinput_Cantidad);
            fieldsArr = Array.prototype.slice.call(fields);
            fieldsArr.forEach(function(current, index, array) {
                current.value = "";
            });
            
            fieldsArr[0].focus();
        },
        
        displayBudget: function(obj) {
            document.querySelector(DOMstrings.budgetLabel).textContent = formatNumber(obj.budget);
        },
        
        displayMonth: function(){
            var now, month, year,months;
            months =["Ene", "Feb", "Mar", "Abr","May", "Jun", "Jul", "Ago", "Sep","Oct", "Nov", "Dic"];
            now = new Date();
            year = now.getFullYear();
            month = now.getMonth();
            
            document.querySelector(DOMstrings.dateLabel).textContent = months[month] +" " +year;
        },

        getDOMstrings: function() {
            return DOMstrings;
        }
    };
    
})();







/* ========================================================================================== */
// GLOBAL APP CONTROLLER
var controller = (function(budgetCtrl, UICtrl) {
    
    var setupEventListeners = function() {
        var DOM = UICtrl.getDOMstrings();
        
        document.querySelector(DOM.HTML_addItemBtn).addEventListener('click', ctrlAddItem);

        document.querySelector(DOM.HTML_rmvItemBtn).addEventListener('click', ctrlDeleteItem);
        
	document.addEventListener('keypress', function(event) {
            if (event.keyCode === 13 || event.which === 13) {
                ctrlAddItem();
            }
        });
        
    };
    
    
    var updateBudget = function() {
        
        // 1. Calculate the budget
        budgetCtrl.calculateBudget();
        
        // 2. Return the budget
        var budget = budgetCtrl.getBudget();
        
        // 3. Display the budget on the UI
        UICtrl.displayBudget(budget);
    };
    
    
    var ctrlAddItem = function() {
        var input, newItem;
        
        // 1. Get the field input data
        input = UICtrl.getInput();        
        
        if (!isNaN(input.cantidad) && input.cantidad > 0) {
            // 2. Add the item to the budget controller
            newItem = budgetCtrl.addItem(input.tipo, input.cantidad);

            // 3. Add the item to the UI
            UICtrl.addListItem(newItem);

            // 4. Clear the fields
            UICtrl.clearFields();

            // 5. Calculate and update budget
            updateBudget();
        }
    };
    
    
    var ctrlDeleteItem = function(event) {
        var itemID, splitID, ID;
        
        itemID = event.target.parentNode.id;
        
        if (itemID) {
            
            splitID = itemID.split('-');
            //type = splitID[0];
            ID = parseInt(splitID[1]);
            
            // 1. delete the item from the data structure
            budgetCtrl.deleteItem(ID);
            
            // 2. Delete the item from the UI
            UICtrl.deleteListItem(itemID);
            
            // 3. Update and show the new budget
            updateBudget();
            
           
        }
    };
    
     
    return {
        init: function() {
            console.log('Application has started.');
            UICtrl.displayMonth();
            UICtrl.displayBudget({
                budget: 0,
            });
            setupEventListeners();
        }
    };
    
})(budgetController, UIController);


controller.init();
