$(function () {
    var header = $("header");
    $('.wapper').scroll(function () {

        var scroll = $('.wapper').scrollTop();
        var h = $('.page-header').height() - 200;
        if (scroll >= 1) {
            header.addClass("fixed");
        } else {
            header.removeClass("fixed");
        }
    });
});


var misVivus = [];
misVivus[1] = new Vivus('my-svg1', { duration: 400 });
misVivus[2] = null;
misVivus[3] = new Vivus('my-svg3', { duration: 600 });

function home() {
    st = true;
    var i = 0;
    $('.wapper').bind('mousewheel', function (e) {
        if (e.originalEvent.wheelDelta / 120 > 0 && st == true) {
            prevSlide();
            st = false;
            setTimeout(function () {
                st = true;
            }, 1200);
        }
        else if (st == true) {

            nextSlide();
            st = false;
            setTimeout(function () {
                st = true;
            }, 1200);
        }
    });

	$(document).keydown(function(e) {
	    switch(e.which) {
	       // case 37: // left
	       //   prevSlide(); break;
	        case 38: // up
	          prevSlide(); break;
	      //  case 39: // right
	      //    nextSlide(); break;
	        case 40: // down
	          nextSlide(); break;
	
	        default: return; // exit this handler for other keys
	    }
	    e.preventDefault(); // prevent the default action (scroll / move caret)
	});

    /* $('.wapper').on('swipedown', function () {
        nextSlide();
        st = false;
        setTimeout(function () {
            st = true;
        }, 1200);
    });
    $('.wapper').on('swipeup', function () {
        prevSlide();
        st = false;
        setTimeout(function () {
            st = true;
        }, 1200);
    }); */

    $('.home-slides-c').swipe({
        swipeUp:function(event, distance, duration, fingerCount, fingerData, currentDirection) {
            prevSlide();
            st = false;
            setTimeout(function () {
                st = true;
            }, 1200);
        },
        swipeDown:function(event, distance, duration, fingerCount, fingerData, currentDirection) {
            nextSlide();
            st = false;
            setTimeout(function () {
                st = true;
            }, 1200);
        },
    });
    $('.slide-num').click(function () {
        nextSlide();
    });
    Number.prototype.pad = function (size) {
        var s = String(this);
        while (s.length < (size || 2)) {
            s = "0" + s;
        }
        return s;
    };
    var nn = 0;

   // for (var bb = 1; bb < $('.slide').length ; ++bb) {
   //     console.log(bb);
   //     vivus1[bb] = new Vivus('svg1slide' + (bb), {duration: 300});
   //     vivus2[bb] = new Vivus('svg2slide' + (bb), {duration: 400});
   // }

    function nextSlide() {
        var els = document.getElementsByClassName("home-svg");
        $('.wapper').addClass('close up');
        $('.slide.op').removeClass('op').next('.slide').addClass('op');
        var lenght = $('.slide').length;
        i++;
        if (i >= lenght) {
            $('.slide').eq(0).addClass('op');
            i = 0;
        }
        console.log('next' + i);
        $('.slide-num p').text((i + 1).pad());
        $('.slide.op .home-svg').removeClass('hide');
        $('.wapper').removeClass('close up');
        $('#home-svg').removeClass('hide');
	
	 misVivus[i+1].reset().play();   
    }

    function prevSlide() {
        var els = document.getElementsByClassName("home-svg");
        $('.wapper').addClass('close up');
        var lenght = $('.slide').length;
        $('.slide.op').removeClass('op');
        i--;
        console.log('prev' + i);
        if (i < 0) {
            i = lenght - 1;
            console.log('prev' + i);
        }
        $('.slide').eq(i).addClass('op');
        $('.slide-num p').text((i + 1).pad());
        $('.slide.op .home-svg').removeClass('hide');
        $('.wapper').removeClass('close up');
        setTimeout(function functionName() {
            $('#home-svg').removeClass('hide');
	 misVivuss[i+1].reset().play();   
	}, 2000);
    }































}

var slider;
/*function menu() {
    $('.manu-c').toggleClass('op');
}*/
function loaded() {

    setTimeout(function () {
        $('body').removeClass('loading');
    }, 500);
    // st1 -> close loading
    // st2 -> open shift
    // st3 -> change shift position
    // st4 -> Close logo
    setTimeout(function () {
        $('header').addClass('st1');
    }, 2000);
    setTimeout(function () {
        $('header').addClass('st2');
    }, 2100);
    setTimeout(function () {
        $('header').addClass('st3');
    }, 3000);
    setTimeout(function () {
        $('header').addClass('st4');
    }, 9500);
    setTimeout(function () {
        $('.wapper').removeClass('hide');
	             misVivus[1].reset().play();

    }, 4500);

}
function projects() {
    $('.projects-c-header').click(function () {
        $(".click-events").toggleClass("op");
        $('.projects-cat').toggleClass('op');
    });
    $(".click-events").click(function () {
        $(this).removeClass("op");
        $(".projects-cat").removeClass("op");
    });
}

function about() {

}





!function (a) {
    var b = /iPhone/i, c = /iPod/i, d = /iPad/i, e = /(?=.*\bAndroid\b)(?=.*\bMobile\b)/i, f = /Android/i,
        g = /(?=.*\bAndroid\b)(?=.*\bSD4930UR\b)/i,
        h = /(?=.*\bAndroid\b)(?=.*\b(?:KFOT|KFTT|KFJWI|KFJWA|KFSOWI|KFTHWI|KFTHWA|KFAPWI|KFAPWA|KFARWI|KFASWI|KFSAWI|KFSAWA)\b)/i,
        i = /Windows Phone/i, j = /(?=.*\bWindows\b)(?=.*\bARM\b)/i, k = /BlackBerry/i, l = /BB10/i, m = /Opera Mini/i,
        n = /(CriOS|Chrome)(?=.*\bMobile\b)/i, o = /(?=.*\bFirefox\b)(?=.*\bMobile\b)/i,
        p = new RegExp("(?:Nexus 7|BNTV250|Kindle Fire|Silk|GT-P1000)", "i"), q = function (a, b) {
            return a.test(b)
        }, r = function (a) {
            var r = a || navigator.userAgent, s = r.split("[FBAN");
            if ("undefined" != typeof s[1] && (r = s[0]), s = r.split("Twitter"), "undefined" != typeof s[1] && (r = s[0]), this.apple = {
                    phone: q(b, r),
                    ipod: q(c, r),
                    tablet: !q(b, r) && q(d, r),
                    device: q(b, r) || q(c, r) || q(d, r)
                }, this.amazon = {
                    phone: q(g, r),
                    tablet: !q(g, r) && q(h, r),
                    device: q(g, r) || q(h, r)
                }, this.android = {
                    phone: q(g, r) || q(e, r),
                    tablet: !q(g, r) && !q(e, r) && (q(h, r) || q(f, r)),
                    device: q(g, r) || q(h, r) || q(e, r) || q(f, r)
                }, this.windows = {
                    phone: q(i, r),
                    tablet: q(j, r),
                    device: q(i, r) || q(j, r)
                }, this.other = {
                    blackberry: q(k, r),
                    blackberry10: q(l, r),
                    opera: q(m, r),
                    firefox: q(o, r),
                    chrome: q(n, r),
                    device: q(k, r) || q(l, r) || q(m, r) || q(o, r) || q(n, r)
                }, this.seven_inch = q(p, r), this.any = this.apple.device || this.android.device || this.windows.device || this.other.device || this.seven_inch, this.phone = this.apple.phone || this.android.phone || this.windows.phone, this.tablet = this.apple.tablet || this.android.tablet || this.windows.tablet, "undefined" == typeof window)return this
        }, s = function () {
            var a = new r;
            return a.Class = r, a
        };
    "undefined" != typeof module && module.exports && "undefined" == typeof window ? module.exports = r : "undefined" != typeof module && module.exports && "undefined" != typeof window ? module.exports = s() : "function" == typeof define && define.amd ? define("isMobile", [], a.isMobile = s()) : a.isMobile = s()
}(this);
(function () {
	'use strict';

	var document = typeof window !== 'undefined' && typeof window.document !== 'undefined' ? window.document : {};
	var isCommonjs = typeof module !== 'undefined' && module.exports;
	var keyboardAllowed = typeof Element !== 'undefined' && 'ALLOW_KEYBOARD_INPUT' in Element;

	var fn = (function () {
		var val;

		var fnMap = [
			[
				'requestFullscreen',
				'exitFullscreen',
				'fullscreenElement',
				'fullscreenEnabled',
				'fullscreenchange',
				'fullscreenerror'
			],
			// New WebKit
			[
				'webkitRequestFullscreen',
				'webkitExitFullscreen',
				'webkitFullscreenElement',
				'webkitFullscreenEnabled',
				'webkitfullscreenchange',
				'webkitfullscreenerror'

			],
			// Old WebKit (Safari 5.1)
			[
				'webkitRequestFullScreen',
				'webkitCancelFullScreen',
				'webkitCurrentFullScreenElement',
				'webkitCancelFullScreen',
				'webkitfullscreenchange',
				'webkitfullscreenerror'

			],
			[
				'mozRequestFullScreen',
				'mozCancelFullScreen',
				'mozFullScreenElement',
				'mozFullScreenEnabled',
				'mozfullscreenchange',
				'mozfullscreenerror'
			],
			[
				'msRequestFullscreen',
				'msExitFullscreen',
				'msFullscreenElement',
				'msFullscreenEnabled',
				'MSFullscreenChange',
				'MSFullscreenError'
			]
		];

		var i = 0;
		var l = fnMap.length;
		var ret = {};

		for (; i < l; i++) {
			val = fnMap[i];
			if (val && val[1] in document) {
				for (i = 0; i < val.length; i++) {
					ret[fnMap[0][i]] = val[i];
				}
				return ret;
			}
		}

		return false;
	})();

	var eventNameMap = {
		change: fn.fullscreenchange,
		error: fn.fullscreenerror
	};

	var screenfull = {
		request: function (elem) {
			return new Promise(function (resolve) {
				var request = fn.requestFullscreen;

				var onFullScreenEntered = function () {
					this.off('change', onFullScreenEntered);
					resolve();
				}.bind(this);

				elem = elem || document.documentElement;

				// Work around Safari 5.1 bug: reports support for
				// keyboard in fullscreen even though it doesn't.
				// Browser sniffing, since the alternative with
				// setTimeout is even worse.
				if (/ Version\/5\.1(?:\.\d+)? Safari\//.test(navigator.userAgent)) {
					elem[request]();
				} else {
					elem[request](keyboardAllowed ? Element.ALLOW_KEYBOARD_INPUT : {});
				}

				this.on('change', onFullScreenEntered);
			}.bind(this));
		},
		exit: function () {
			return new Promise(function (resolve) {
				var onFullScreenExit = function () {
					this.off('change', onFullScreenExit);
					resolve();
				}.bind(this);

				document[fn.exitFullscreen]();

				this.on('change', onFullScreenExit);
			}.bind(this));
		},
		toggle: function (elem) {
			return this.isFullscreen ? this.exit() : this.request(elem);
		},
		onchange: function (callback) {
			this.on('change', callback);
		},
		onerror: function (callback) {
			this.on('error', callback);
		},
		on: function (event, callback) {
			var eventName = eventNameMap[event];
			if (eventName) {
				document.addEventListener(eventName, callback, false);
			}
		},
		off: function (event, callback) {
			var eventName = eventNameMap[event];
			if (eventName) {
				document.removeEventListener(eventName, callback, false);
			}
		},
		raw: fn
	};

	if (!fn) {
		if (isCommonjs) {
			module.exports = false;
		} else {
			window.screenfull = false;
		}

		return;
	}

	Object.defineProperties(screenfull, {
		isFullscreen: {
			get: function () {
				return Boolean(document[fn.fullscreenElement]);
			}
		},
		element: {
			enumerable: true,
			get: function () {
				return document[fn.fullscreenElement];
			}
		},
		enabled: {
			enumerable: true,
			get: function () {
				// Coerce to boolean in case of old WebKit
				return Boolean(document[fn.fullscreenEnabled]);
			}
		}
	});

	if (isCommonjs) {
		module.exports = screenfull;
	} else {
		window.screenfull = screenfull;
	}
})();

